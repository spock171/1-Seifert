Font is public domain and was obtained from http://www.fontspace.com/lcd-solid/lcd-solid
